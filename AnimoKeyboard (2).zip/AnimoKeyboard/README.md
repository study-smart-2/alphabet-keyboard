# Animo Keyboard

Android keyboard with a full QWERTY typing layout (letters, numbers, symbols, ₹) plus 76 animated emojis (reactions, study, A-Z, 0-9, signs). Tap an emoji to send it as a GIF.

## Get the APK (no PC needed)
1. Create a new GitHub repo and upload everything in this folder (keep the `.github` folder).
2. Open the **Actions** tab, wait for "Build APK" to turn green (about 3-5 min).
3. Open the repo's **Releases** page, download `app-debug.apk` on your phone and install it.

## Use it
1. Open *Animo Keyboard* -> "Open keyboard settings" -> turn on **Animo Emoji**.
2. In any chat tap the keyboard-switch icon -> pick **Animo Emoji**.
3. Type normally. Tap the yellow 😀 key for animated emojis, ABC to come back. 🌐 switches to your other keyboard.

Apps that don't accept GIFs from keyboards get the emoji copied to the clipboard instead.

## Add or change emojis
Drop 256x256 looping transparent GIFs into `app/src/main/assets/emoji/` and add a line
`id|react-or-study|Label` to `manifest.txt` in the same folder.
