package com.fourth.animo

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class SetupActivity : Activity() {

    private lateinit var status1: TextView
    private lateinit var status2: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(28))
        }

        col.addView(TextView(this).apply {
            text = "Animo Keyboard"
            textSize = 28f
            setTextColor(Color.parseColor("#1F2430"))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        col.addView(TextView(this).apply {
            text = "26 animated emojis that you can send from any app that accepts GIFs from the keyboard (WhatsApp, Telegram, Messages, etc.)."
            textSize = 15f
            setTextColor(Color.parseColor("#4A5163"))
            setPadding(0, dp(6), 0, dp(20))
        })

        fun card(title: String, body: String, btn: String, onClick: () -> Unit): TextView {
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16), dp(14), dp(16), dp(14))
                background = GradientDrawable().apply {
                    cornerRadius = dp(16).toFloat()
                    setColor(Color.WHITE)
                    setStroke(dp(1), Color.parseColor("#DDE0EA"))
                }
            }
            box.addView(TextView(this).apply {
                text = title
                textSize = 17f
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                setTextColor(Color.parseColor("#1F2430"))
            })
            val st = TextView(this).apply {
                text = body
                textSize = 14f
                setTextColor(Color.parseColor("#4A5163"))
                setPadding(0, dp(4), 0, dp(8))
            }
            box.addView(st)
            box.addView(Button(this).apply {
                text = btn
                setOnClickListener { onClick() }
            })
            col.addView(box, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(14)
            })
            return st
        }

        status1 = card("1. Enable the keyboard", "", "Open keyboard settings") {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }
        status2 = card("2. Switch to it", "", "Choose keyboard") {
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }
        card(
            "3. Use it",
            "In any chat, tap the keyboard-switch icon and pick “Animo Emoji”. Tap an emoji to send it. Use the ⌨ button on the keyboard to go back to your normal keyboard (long-press for the picker).",
            "Try it below"
        ) { findViewById<EditText>(1001).requestFocus() }

        col.addView(EditText(this).apply {
            id = 1001
            hint = "Test box — emojis will appear here if supported"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            gravity = Gravity.TOP
            minLines = 3
        })

        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onResume() {
        super.onResume()
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        val enabled = imm.enabledInputMethodList.any { it.packageName == packageName }
        val current = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)?.startsWith("$packageName/") == true
        status1.text = if (enabled) "✅ Enabled" else "Turn on “Animo Emoji” in the list."
        status2.text = if (current) "✅ Active right now" else "Pick “Animo Emoji” from the popup when typing."
    }
}
