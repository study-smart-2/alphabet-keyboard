package com.fourth.animo

import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.core.view.inputmethod.EditorInfoCompat
import androidx.core.view.inputmethod.InputConnectionCompat
import androidx.core.view.inputmethod.InputContentInfoCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class AnimoIME : InputMethodService() {

    private enum class Mode { LETTERS, SYMBOLS, EMOJI }

    private companion object {
        val BG = Color.parseColor("#1F2430")
        val KEY = Color.parseColor("#2F3649")
        val KEY_SPECIAL = Color.parseColor("#454E66")
        val ACCENT = Color.parseColor("#FFCC33")
        val DARK = Color.parseColor("#1F2430")
        const val KEYBOARD_HEIGHT_DP = 290
    }

    private var mode = Mode.LETTERS
    private var shifted = false
    private var capsLock = false
    private var lastShiftTap = 0L

    private lateinit var content: FrameLayout
    private var emojiPanel: View? = null
    private lateinit var grid: RecyclerView
    private lateinit var adapter: EmojiAdapter
    private val tabViews = LinkedHashMap<String, TextView>()

    private val letterKeys = ArrayList<TextView>()
    private var shiftKey: TextView? = null

    private val handler = Handler(Looper.getMainLooper())
    private var repeatRunnable: Runnable? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int = 8) = GradientDrawable().apply {
        cornerRadius = dp(radiusDp).toFloat()
        setColor(color)
    }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreateInputView(): View {
        content = FrameLayout(this).apply {
            setBackgroundColor(BG)
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(KEYBOARD_HEIGHT_DP))
        }
        render()
        return content
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        val cls = (info?.inputType ?: 0) and InputType.TYPE_MASK_CLASS
        mode = if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE ||
            cls == InputType.TYPE_CLASS_DATETIME) Mode.SYMBOLS else Mode.LETTERS
        capsLock = false
        shifted = autoCapWanted()
        if (::content.isInitialized) render()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        stopRepeat()
    }

    // ------------------------------------------------------------------ rendering

    private fun render() {
        stopRepeat()
        content.removeAllViews()
        if (mode == Mode.EMOJI) {
            content.addView(emojiPanel ?: buildEmojiPanel().also { emojiPanel = it },
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        } else {
            content.addView(buildKeys(),
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
    }

    private fun stopRepeat() {
        repeatRunnable?.let { handler.removeCallbacks(it) }
        repeatRunnable = null
    }

    /** A single key. Fires on touch-down for speed; optionally auto-repeats while held. */
    private fun keyView(
        label: String,
        weight: Float,
        bg: Int = KEY,
        fg: Int = Color.WHITE,
        size: Float = 19f,
        repeat: Boolean = false,
        onTap: () -> Unit
    ): TextView {
        val tv = TextView(this)
        tv.text = label
        tv.textSize = size
        tv.setTextColor(fg)
        tv.gravity = Gravity.CENTER
        tv.background = rounded(bg)
        tv.isSingleLine = true
        tv.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight).apply {
            setMargins(dp(2), dp(3), dp(2), dp(3))
        }
        tv.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.alpha = 0.55f
                    onTap()
                    if (repeat) {
                        stopRepeat()
                        val r = object : Runnable {
                            override fun run() {
                                onTap()
                                handler.postDelayed(this, 55)
                            }
                        }
                        repeatRunnable = r
                        handler.postDelayed(r, 400)
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.alpha = 1f
                    stopRepeat()
                }
            }
            true
        }
        return tv
    }

    private fun spacer(weight: Float) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight)
    }

    private fun buildKeys(): View {
        letterKeys.clear()
        shiftKey = null
        val letters = mode == Mode.LETTERS

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(3), dp(4), dp(3), dp(4))
        }

        fun addRow(vararg views: View) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            views.forEach { row.addView(it) }
            col.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }

        // Row 0: numbers (both pages)
        addRow(*"1234567890".map { plainKey(it.toString()) }.toTypedArray())

        val del = keyView("\u232B", 1.5f, bg = KEY_SPECIAL, repeat = true) { deleteBackward() }

        if (letters) {
            addRow(*"qwertyuiop".map { letterKey(it) }.toTypedArray())
            addRow(spacer(0.5f), *"asdfghjkl".map { letterKey(it) }.toTypedArray(), spacer(0.5f))
            val shift = keyView(
                if (capsLock) "\u21EA" else "\u21E7", 1.5f,
                bg = if (shifted) ACCENT else KEY_SPECIAL,
                fg = if (shifted) DARK else Color.WHITE
            ) { onShiftTap() }
            shiftKey = shift
            addRow(shift, *"zxcvbnm".map { letterKey(it) }.toTypedArray(), del)
        } else {
            addRow(*"@#\$\u20B9%&-+()".map { plainKey(it.toString()) }.toTypedArray())
            addRow(*"_/*\"':;!?".map { plainKey(it.toString()) }.toTypedArray(), del)
        }

        // Bottom row
        addRow(
            keyView(if (letters) "?123" else "ABC", 1.4f, bg = KEY_SPECIAL, size = 15f) {
                setMode(if (letters) Mode.SYMBOLS else Mode.LETTERS)
            },
            keyView("\uD83C\uDF10", 1f, bg = KEY_SPECIAL, size = 17f) { switchKeyboard() },
            keyView("\uD83D\uDE00", 1f, bg = ACCENT, fg = DARK, size = 19f) { setMode(Mode.EMOJI) },
            plainKey(","),
            keyView("Animo", 3.2f, size = 14f) { typeText(" ") },
            plainKey("."),
            keyView(enterLabel(), 1.4f, bg = ACCENT, fg = DARK) { onEnter() }
        )
        return col
    }

    private fun plainKey(s: String, w: Float = 1f): TextView =
        keyView(s, w) { typeText(s) }

    private fun letterKey(ch: Char): TextView {
        val lower = ch.toString()
        val k = keyView(if (shifted) lower.uppercase() else lower, 1f) {
            typeText(if (shifted) lower.uppercase() else lower)
        }
        k.tag = lower
        letterKeys.add(k)
        return k
    }

    // ------------------------------------------------------------------ typing

    private fun typeText(s: String) {
        val ic = currentInputConnection ?: return
        ic.commitText(s, 1)
        if (mode == Mode.LETTERS && !capsLock) {
            val want = autoCapWanted()
            if (want != shifted) {
                shifted = want
                refreshLetterCase()
            }
        }
    }

    private fun autoCapWanted(): Boolean {
        val ei = currentInputEditorInfo ?: return false
        if (ei.inputType == InputType.TYPE_NULL) return false
        val ic = currentInputConnection ?: return false
        return ic.getCursorCapsMode(ei.inputType) != 0
    }

    private fun refreshLetterCase() {
        for (k in letterKeys) {
            val lower = k.tag as String
            k.text = if (shifted) lower.uppercase() else lower
        }
        shiftKey?.let {
            it.text = if (capsLock) "⇪" else "⇧"
            it.background = rounded(if (shifted) ACCENT else KEY_SPECIAL)
            it.setTextColor(if (shifted) DARK else Color.WHITE)
        }
    }

    private fun deleteBackward() {
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)
        if (sel != null && sel.isNotEmpty()) ic.commitText("", 1)
        else ic.deleteSurroundingText(1, 0)
    }

    private fun onEnter() {
        val ei = currentInputEditorInfo
        val ic = currentInputConnection ?: return
        if (ei != null) {
            val action = ei.imeOptions and EditorInfo.IME_MASK_ACTION
            val noAction = (ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
            if (!noAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
                ic.performEditorAction(action)
                return
            }
        }
        sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
    }

    private fun enterLabel(): String {
        val ei = currentInputEditorInfo ?: return "⏎"
        if ((ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0) return "⏎"
        return when (ei.imeOptions and EditorInfo.IME_MASK_ACTION) {
            EditorInfo.IME_ACTION_SEND -> "➤"
            EditorInfo.IME_ACTION_SEARCH -> "🔍"
            EditorInfo.IME_ACTION_GO, EditorInfo.IME_ACTION_NEXT -> "→"
            EditorInfo.IME_ACTION_DONE -> "✓"
            else -> "⏎"
        }
    }

    private fun onShiftTap() {
        val now = System.currentTimeMillis()
        if (now - lastShiftTap < 350) {
            capsLock = true
            shifted = true
        } else if (capsLock) {
            capsLock = false
            shifted = false
        } else {
            shifted = !shifted
        }
        lastShiftTap = now
        refreshLetterCase()
    }

    private fun setMode(m: Mode) {
        mode = m
        render()
    }

    private fun switchKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        if (!switchToNextInputMethod(false)) imm.showInputMethodPicker()
    }

    private fun pickKeyboard() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
    }

    // ------------------------------------------------------------------ emoji panel

    private fun buildEmojiPanel(): View {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(4), dp(6), dp(4))
        }

        fun barButton(label: String, onClick: () -> Unit, onLong: (() -> Unit)? = null) = TextView(this).apply {
            text = label
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = rounded(KEY_SPECIAL, 16)
            setPadding(dp(14), dp(6), dp(14), dp(6))
            setOnClickListener { onClick() }
            if (onLong != null) setOnLongClickListener { onLong(); true }
        }

        fun gap() = View(this).apply { layoutParams = LinearLayout.LayoutParams(dp(6), 1) }

        bar.addView(barButton("ABC", { setMode(Mode.LETTERS) }))
        bar.addView(gap())

        val tabRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        fun tab(key: String, text: String) {
            val tv = TextView(this).apply {
                this.text = text
                textSize = 14f
                isSingleLine = true
                setPadding(dp(12), dp(7), dp(12), dp(7))
                setOnClickListener { selectCat(key) }
            }
            tabViews[key] = tv
            tabRow.addView(tv)
        }
        tab("all", "All")
        tab("react", "Reactions")
        tab("study", "Study")
        tab("alpha", "A\u2013Z")
        tab("num", "0\u20139")
        tab("sign", "Signs")

        val scroller = android.widget.HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(tabRow)
        }
        bar.addView(scroller, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(gap())
        bar.addView(barButton("\uD83C\uDF10", { switchKeyboard() }, { pickKeyboard() }))
        bar.addView(gap())

        val del = barButton("⌫", { })
        del.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.alpha = 0.55f
                    deleteBackward()
                    stopRepeat()
                    val r = object : Runnable {
                        override fun run() {
                            deleteBackward()
                            handler.postDelayed(this, 55)
                        }
                    }
                    repeatRunnable = r
                    handler.postDelayed(r, 400)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.alpha = 1f
                    stopRepeat()
                }
            }
            true
        }
        bar.addView(del)
        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        adapter = EmojiAdapter(EmojiStore.all(this)) { send(it) }
        grid = RecyclerView(this).apply {
            layoutManager = GridLayoutManager(this@AnimoIME, 4)
            this.adapter = this@AnimoIME.adapter
            setPadding(dp(6), dp(2), dp(6), dp(6))
            clipToPadding = false
            itemAnimator = null
        }
        root.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        selectCat("all")
        return root
    }

    private fun selectCat(cat: String) {
        for ((k, tv) in tabViews) {
            val on = k == cat
            tv.setTextColor(if (on) DARK else Color.parseColor("#C9CEDC"))
            tv.background = rounded(if (on) ACCENT else Color.TRANSPARENT, 16)
        }
        val all = EmojiStore.all(this)
        adapter.submit(if (cat == "all") all else all.filter { it.cat == cat })
        grid.scrollToPosition(0)
    }

    private fun supportsGif(info: EditorInfo?): Boolean {
        if (info == null) return false
        val types = EditorInfoCompat.getContentMimeTypes(info)
        return types.any { ClipDescription.compareMimeTypes("image/gif", it) }
    }

    private fun send(e: Emoji) {
        val file = EmojiStore.cacheFile(this, e)
        val uri: Uri = FileProvider.getUriForFile(this, "$packageName.files", file)
        val info = currentInputEditorInfo
        val ic = currentInputConnection
        if (ic != null && supportsGif(info)) {
            val contentInfo = InputContentInfoCompat(uri, ClipDescription(e.label, arrayOf("image/gif")), null)
            val flags = InputConnectionCompat.INPUT_CONTENT_GRANT_READ_URI_PERMISSION
            val ok = InputConnectionCompat.commitContent(ic, info!!, contentInfo, flags, null)
            if (ok) return
        }
        // Fallback: this app does not accept GIFs from keyboards. Copy it so it can be pasted.
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData("emoji", arrayOf("image/gif"), ClipData.Item(uri)))
        grantUriPermission(info?.packageName ?: packageName, uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        Toast.makeText(this, "This app doesn't take GIFs from keyboards. Copied — long-press the text box and paste.", Toast.LENGTH_LONG).show()
    }

    // ------------------------------------------------------------------

    private class EmojiAdapter(
        private var items: List<Emoji>,
        private val onPick: (Emoji) -> Unit
    ) : RecyclerView.Adapter<EmojiAdapter.VH>() {

        class VH(val frame: FrameLayout, val img: ImageView) : RecyclerView.ViewHolder(frame) {
            var drawable: AnimatedImageDrawable? = null
        }

        fun submit(list: List<Emoji>) {
            items = list
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val ctx = parent.context
            val d = ctx.resources.displayMetrics.density
            val frame = FrameLayout(ctx)
            val h = (84 * d).toInt()
            val pad = (4 * d).toInt()
            frame.setPadding(pad, pad, pad, pad)
            frame.background = GradientDrawable().apply {
                cornerRadius = 14 * d
                setColor(Color.parseColor("#2A3040"))
            }
            val img = ImageView(ctx).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
            frame.addView(img, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            val lp = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h)
            lp.setMargins(pad, pad, pad, pad)
            frame.layoutParams = lp
            return VH(frame, img)
        }

        override fun onBindViewHolder(h: VH, pos: Int) {
            val e = items[pos]
            try {
                val src = ImageDecoder.createSource(h.frame.context.assets, e.assetPath)
                val dr = ImageDecoder.decodeDrawable(src) { dec, _, _ ->
                    dec.setTargetSampleSize(2)
                }
                h.img.setImageDrawable(dr)
                (dr as? AnimatedImageDrawable)?.let {
                    it.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                    it.start()
                    h.drawable = it
                }
            } catch (ex: Exception) {
                h.img.setImageDrawable(null)
            }
            h.frame.setOnClickListener { onPick(e) }
            h.frame.setOnTouchListener { v, ev ->
                when (ev.action) {
                    MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(80).start()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                }
                false
            }
        }

        override fun onViewRecycled(h: VH) {
            h.drawable?.stop()
            h.drawable = null
            h.img.setImageDrawable(null)
        }

        override fun getItemCount() = items.size
    }
}
