package com.fourth.animo

import android.content.Context
import java.io.File

data class Emoji(val id: String, val cat: String, val label: String) {
    val assetPath get() = "emoji/$id.gif"
}

object EmojiStore {
    private var cache: List<Emoji>? = null

    fun all(ctx: Context): List<Emoji> {
        cache?.let { return it }
        val list = ctx.assets.open("emoji/manifest.txt").bufferedReader().readLines()
            .filter { it.isNotBlank() }
            .map {
                val p = it.split("|")
                Emoji(p[0], p[1], p[2])
            }
        cache = list
        return list
    }

    /** Copies the asset into cache so it can be shared through the FileProvider. */
    fun cacheFile(ctx: Context, e: Emoji): File {
        val dir = File(ctx.cacheDir, "emoji").apply { mkdirs() }
        val f = File(dir, "${e.id}.gif")
        if (!f.exists() || f.length() == 0L) {
            ctx.assets.open(e.assetPath).use { input ->
                f.outputStream().use { input.copyTo(it) }
            }
        }
        return f
    }
}
