package com.yourname.emojikeyboard

import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.core.view.inputmethod.EditorInfoCompat
import androidx.core.view.inputmethod.InputConnectionCompat
import androidx.core.view.inputmethod.InputContentInfoCompat
import java.io.File

class EmojiKeyboardService : InputMethodService() {

    // Styles 0..2 = colored images (sent as PNG): Green 3D, Lime, Mix (both colors alternate).
    // Styles 3.. = Unicode text letters.
    private val imageStyles = listOf("green3d", "lime", "mix")
    private val textUpper = intArrayOf(0x24B6, 0x1F150, 0x1F130, 0x1F170, 0x1D400, 0x1D5D4)
    private val textLower = intArrayOf(0x24D0, 0, 0, 0, 0x1D41A, 0x1D5EE) // 0 = no small letters

    private var current = 0
    private var upper = true

    private val buffer = StringBuilder()
    private val keys = ArrayList<CharKey>()
    private val chips = ArrayList<View>()
    private val cache = HashMap<String, Bitmap>()
    private var previewScroll: HorizontalScrollView? = null
    private var previewRow: LinearLayout? = null
    private var enterKey: TextView? = null
    private var shiftKey: TextView? = null

    private fun isImageMode() = current < imageStyles.size
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun styled(c: Char, t: Int = current - imageStyles.size): String =
        if (c.isLowerCase() && textLower[t] != 0)
            String(Character.toChars(textLower[t] + (c - 'a')))
        else
            String(Character.toChars(textUpper[t] + (c.uppercaseChar() - 'A')))

    private fun bg(color: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(8).toFloat()
    }

    private fun assetName(c: Char) = when {
        c.isUpperCase() -> "u_$c"
        c.isLowerCase() -> "l_$c"
        else -> "$c"
    }

    private fun bitmapFor(style: String, c: Char): Bitmap? = try {
        cache.getOrPut("$style/$c") {
            assets.open("letters/$style/${assetName(c)}.png").use { BitmapFactory.decodeStream(it) }
        }
    } catch (e: Exception) {
        null
    }

    // Which color the n-th letter of a word uses
    private fun styleAt(n: Int): String {
        val s = imageStyles[current]
        return if (s == "mix") (if (n % 2 == 0) "green3d" else "lime") else s
    }

    private fun partsFor(text: String): List<Bitmap?> {
        var n = 0
        return text.map { ch ->
            if (ch == ' ') null else {
                val b = bitmapFor(styleAt(n), ch)
                n++
                b
            }
        }
    }

    private fun mixChipBitmap(): Bitmap? {
        val a = bitmapFor("green3d", 'A') ?: return null
        val b = bitmapFor("lime", 'J') ?: return null
        val out = Bitmap.createBitmap(a.width + b.width + 6, 256, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        canvas.drawBitmap(a, 0f, 0f, null)
        canvas.drawBitmap(b, (a.width + 6).toFloat(), 0f, null)
        return out
    }

    private fun type(s: String) {
        currentInputConnection?.commitText(s, 1)
    }

    private fun key(label: String, weight: Float, onTap: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            textSize = 20f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
            background = bg(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(0, dp(42), weight).apply {
                setMargins(dp(2), dp(3), dp(2), dp(3))
            }
            setOnClickListener { onTap() }
        }

    private fun row() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }

    private fun spacer(weight: Float) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(0, 1, weight)
    }

    // A letter/number key that shows either a colored image or a text glyph
    private inner class CharKey(val c: Char) {
        val tv = TextView(this@EmojiKeyboardService).apply {
            textSize = 20f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
        }
        val iv = ImageView(this@EmojiKeyboardService).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(5), dp(5), dp(5), dp(5))
            visibility = View.GONE
        }
        val view = FrameLayout(this@EmojiKeyboardService).apply {
            background = bg(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(0, dp(42), 1f).apply {
                setMargins(dp(2), dp(3), dp(2), dp(3))
            }
            addView(tv, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            addView(iv, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            setOnClickListener { onChar(shown()) }
        }

        fun shown(): Char = if (c.isLetter() && !upper) c.lowercaseChar() else c

        fun refresh() {
            if (isImageMode()) {
                tv.visibility = View.GONE
                iv.visibility = View.VISIBLE
                // In Mix mode the key previews the color the next letter will get
                iv.setImageBitmap(bitmapFor(styleAt(buffer.count { it != ' ' }), shown()))
            } else {
                iv.visibility = View.GONE
                tv.visibility = View.VISIBLE
                tv.text = if (c.isDigit()) c.toString() else styled(shown())
            }
        }
    }

    private fun onChar(c: Char) {
        if (isImageMode()) {
            buffer.append(c)
            refreshBuffer()
        } else {
            type(if (c.isDigit()) c.toString() else styled(c))
        }
    }

    private fun onSpace() {
        if (isImageMode() && buffer.isNotEmpty()) {
            buffer.append(' ')
            refreshBuffer()
        } else {
            type(" ")
        }
    }

    private fun onDelete() {
        if (isImageMode() && buffer.isNotEmpty()) {
            buffer.setLength(buffer.length - 1)
            refreshBuffer()
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        }
    }

    private fun onEnter() {
        if (isImageMode() && buffer.isNotEmpty()) sendImage() else sendDefaultEditorAction(true)
    }

    private fun refreshBuffer() {
        enterKey?.text = if (isImageMode() && buffer.isNotEmpty()) "➤" else "⏎"
        if (imageStyles.getOrNull(current) == "mix") keys.forEach { it.refresh() }
        val row = previewRow ?: return
        row.removeAllViews()
        if (!isImageMode()) return
        if (buffer.isEmpty()) {
            row.addView(TextView(this).apply {
                text = "Tap letters, then press ➤ to send"
                setTextColor(Color.parseColor("#7A5FB0"))
                textSize = 14f
                setPadding(dp(10), 0, dp(10), 0)
            })
            return
        }
        for (b in partsFor(buffer.toString())) {
            if (b == null) {
                row.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(dp(14), 1) })
            } else {
                row.addView(ImageView(this).apply {
                    setImageBitmap(b)
                    adjustViewBounds = true
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)
                    ).apply { setMargins(dp(1), 0, dp(1), 0) }
                })
            }
        }
        previewScroll?.post { previewScroll?.fullScroll(View.FOCUS_RIGHT) }
    }

    private fun refresh() {
        keys.forEach { it.refresh() }
        chips.forEachIndexed { i, v ->
            v.background = bg(if (i == current) Color.parseColor("#CDB4F2") else Color.TRANSPARENT)
        }
        shiftKey?.background = bg(if (upper) Color.parseColor("#CDB4F2") else Color.WHITE)
        previewScroll?.visibility = if (isImageMode()) View.VISIBLE else View.GONE
        refreshBuffer()
    }

    // Stitch the typed letters into one PNG and insert it
    private fun sendImage() {
        val text = buffer.toString().trim()
        if (text.isEmpty()) return
        val parts = partsFor(text)
        val letterGap = 4
        val spaceGap = 60
        var width = 0
        for (b in parts) width += if (b == null) spaceGap else b.width + letterGap
        val out = Bitmap.createBitmap(maxOf(width, 1), 256, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        var x = 0
        for (b in parts) {
            if (b == null) {
                x += spaceGap
            } else {
                canvas.drawBitmap(b, x.toFloat(), 0f, null)
                x += b.width + letterGap
            }
        }
        val dir = File(cacheDir, "emoji").apply { mkdirs() }
        val now = System.currentTimeMillis()
        dir.listFiles()?.forEach { if (now - it.lastModified() > 10 * 60 * 1000) it.delete() }
        val file = File(dir, "aj_$now.png")
        file.outputStream().use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
        commitImage(file)
    }

    private fun commitImage(file: File) {
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val ic = currentInputConnection ?: return
        val info = currentInputEditorInfo

        val accepted = EditorInfoCompat.getContentMimeTypes(info)
            .any { ClipDescription.compareMimeTypes("image/png", it) }
        if (accepted) {
            val content = InputContentInfoCompat(
                uri, ClipDescription(file.name, arrayOf("image/png")), null
            )
            val flags =
                if (Build.VERSION.SDK_INT >= 25)
                    InputConnectionCompat.INPUT_CONTENT_GRANT_READ_URI_PERMISSION
                else 0
            if (InputConnectionCompat.commitContent(ic, info, content, flags, null)) {
                buffer.setLength(0)
                refreshBuffer()
                return
            }
        }
        // Fallback: copy to clipboard so the user can paste it
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newUri(contentResolver, file.name, uri))
        Toast.makeText(this, "Image copied. Long-press in the box and paste.", Toast.LENGTH_LONG).show()
        buffer.setLength(0)
        refreshBuffer()
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        if (!restarting) {
            buffer.setLength(0)
            if (previewRow != null) refreshBuffer()
        }
    }

    override fun onCreateInputView(): View {
        keys.clear()
        chips.clear()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#F3EEFB"))
            setPadding(dp(4), dp(4), dp(4), dp(8))
        }

        // Style selector: 3 colored image styles, then 6 text styles
        val chipRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (i in imageStyles.indices) {
            val isMix = imageStyles[i] == "mix"
            val chip = ImageView(this).apply {
                setImageBitmap(if (isMix) mixChipBitmap() else bitmapFor(imageStyles[i], 'A'))
                scaleType = ImageView.ScaleType.FIT_CENTER
                setPadding(dp(8), dp(4), dp(8), dp(4))
                layoutParams = LinearLayout.LayoutParams(if (isMix) dp(84) else dp(52), dp(40))
                setOnClickListener { current = i; refresh() }
            }
            chips.add(chip)
            chipRow.addView(chip)
        }
        for (t in textUpper.indices) {
            val idx = imageStyles.size + t
            val chip = TextView(this).apply {
                text = styled('A', t)
                textSize = 22f
                gravity = Gravity.CENTER
                setPadding(dp(14), dp(4), dp(14), dp(4))
                setOnClickListener { current = idx; refresh() }
            }
            chips.add(chip)
            chipRow.addView(chip)
        }
        root.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(chipRow)
        })

        // Word preview (visible only for colored styles)
        val pRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        previewRow = pRow
        val pScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            background = bg(Color.parseColor("#E6DAF8"))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(48)
            ).apply { setMargins(dp(2), dp(2), dp(2), dp(4)) }
            addView(pRow, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        previewScroll = pScroll
        root.addView(pScroll)

        // Numbers
        root.addView(row().apply {
            for (d in "1234567890") {
                val k = CharKey(d)
                keys.add(k)
                addView(k.view)
            }
        })

        // Letters (⇧ toggles ABC / abc)
        val rows = listOf("QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM")
        rows.forEachIndexed { idx, letters ->
            root.addView(row().apply {
                if (idx == 1) addView(spacer(0.5f))
                if (idx == 2) {
                    val shift = key("⇧", 1.5f) { upper = !upper; refresh() }
                    shiftKey = shift
                    addView(shift)
                }
                for (c in letters) {
                    val k = CharKey(c)
                    keys.add(k)
                    addView(k.view)
                }
                if (idx == 1) addView(spacer(0.5f))
                if (idx == 2) addView(key("⌫", 1.5f) { onDelete() })
            })
        }

        // Bottom row
        root.addView(row().apply {
            addView(key("🌐", 1.5f) {
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
            })
            addView(key(",", 1f) { type(",") })
            addView(key("space", 5f) { onSpace() })
            addView(key(".", 1f) { type(".") })
            val enter = key("⏎", 1.5f) { onEnter() }
            enterKey = enter
            addView(enter)
        })

        refresh()
        return root
    }
}
