# AJ Keyboard
Colored 3D letters (Green 3D, Lime, Mix; capital and small) sent as images, plus styled Unicode letters typed as text.
Built on GitHub Actions, no Android Studio needed.
