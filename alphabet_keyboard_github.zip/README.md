# Alphabet Emoji Keyboard

Build automatically on GitHub (no Android Studio needed).
Upload all files to a GitHub repo (branch: main). Open Actions tab, wait for the green tick,
then download AlphabetEmoji.apk from the Releases section and install it on your phone.
