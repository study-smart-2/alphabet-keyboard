# AJ Keyboard
Plain keyboard (8 languages), colored 3D letters + signs (8 colors and combinations),
styled text letters, emoji, stickers and GIF search (GIPHY key needed).
Built on GitHub Actions, no Android Studio needed.
