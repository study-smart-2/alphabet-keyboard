package com.yourname.emojikeyboard

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

// Pick the color theme of the keyboard (key letters, key background, keyboard background)
class ThemePanel(private val host: Host) : Panel {
    private val ctx: Context = host.ctx
    private val container = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    override val view: View get() = container

    init {
        val themes = Ui.themes
        var i = 0
        while (i < themes.size) {
            val row = Ui.row(ctx)
            val end = minOf(i + 3, themes.size)
            for (j in i until end) {
                val t = themes[j]
                val textColor = if (t.rainbow) Color.parseColor("#E53935") else Color.parseColor(t.keyText)
                val bgDrawable = Ui.bg(ctx, Color.parseColor(t.keyBg), 12)
                if (j == Ui.themeIdx) bgDrawable.setStroke(Ui.dp(ctx, 3), textColor)
                val k = TextView(ctx).apply {
                    text = if (j == Ui.themeIdx) t.name + " ✓" else t.name
                    textSize = 16f
                    setTypeface(null, Typeface.BOLD)
                    gravity = Gravity.CENTER
                    setTextColor(textColor)
                    background = bgDrawable
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                        setMargins(Ui.dp(ctx, 4), Ui.dp(ctx, 4), Ui.dp(ctx, 4), Ui.dp(ctx, 4))
                    }
                    setOnClickListener {
                        Ui.saveTheme(ctx, j)
                        host.recreateKeyboard()
                    }
                }
                row.addView(k)
            }
            for (p in end until i + 3) row.addView(Ui.spacer(ctx, 1f))
            container.addView(row)
            i += 3
        }
    }
}
