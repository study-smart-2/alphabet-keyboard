package com.yourname.emojikeyboard

import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.drawable.ColorDrawable
import com.bumptech.glide.Glide
import java.io.File

// Ready-made colored word stickers (sent as PNG images)
class StickerPanel(private val host: Host) : Panel {
    private val ctx: Context = host.ctx
    private val packs = listOf("green3d" to "Green", "gold" to "Gold", "rainbow" to "Rainbow", "pinkpurple" to "Pink")
    private var pack = packs[0].first
    private var items: List<String> = emptyList()
    private var grid: GridView? = null
    private val tabs = ArrayList<TextView>()

    override val view: View by lazy { build() }

    override fun onShow() {
        if (items.isEmpty()) select(0)
    }

    private fun select(i: Int) {
        pack = packs[i].first
        items = (ctx.assets.list("stickers/$pack") ?: emptyArray()).sorted()
        grid?.adapter = Adapter()
        tabs.forEachIndexed { idx, t ->
            t.background = Ui.bg(ctx, if (idx == i) Color.parseColor(Ui.LAV) else Color.TRANSPARENT)
        }
    }

    private fun send(name: String) {
        val dir = File(ctx.cacheDir, "emoji").apply { mkdirs() }
        val f = File(dir, "st_${pack}_$name")
        if (!f.exists()) {
            ctx.assets.open("stickers/$pack/$name").use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        }
        host.commitFile(f, "image/png")
    }

    private inner class Adapter : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val iv = (convertView as? ImageView) ?: ImageView(ctx).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                setPadding(Ui.dp(ctx, 6), Ui.dp(ctx, 6), Ui.dp(ctx, 6), Ui.dp(ctx, 6))
                layoutParams = AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(ctx, 76))
            }
            Glide.with(ctx.applicationContext)
                .load("file:///android_asset/stickers/$pack/${items[position]}")
                .into(iv)
            return iv
        }
    }

    private fun build(): View {
        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        packs.forEachIndexed { i, p ->
            val tv = TextView(ctx).apply {
                text = p.second
                textSize = 15f
                gravity = Gravity.CENTER
                setPadding(Ui.dp(ctx, 16), 0, Ui.dp(ctx, 16), 0)
                setOnClickListener { select(i) }
            }
            tabs.add(tv)
            row.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        root.addView(
            HorizontalScrollView(ctx).apply {
                isHorizontalScrollBarEnabled = false
                addView(row, FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
            },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(ctx, 40))
        )
        val g = GridView(ctx).apply {
            numColumns = 3
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            selector = ColorDrawable(Color.TRANSPARENT)
            setOnItemClickListener { _, _, pos, _ -> send(items[pos]) }
        }
        grid = g
        root.addView(g, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        select(0)
        return root
    }
}
