package com.yourname.emojikeyboard

import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.core.view.inputmethod.EditorInfoCompat
import androidx.core.view.inputmethod.InputConnectionCompat
import androidx.core.view.inputmethod.InputContentInfoCompat
import java.io.File

class AJKeyboardService : InputMethodService(), Host {

    override val ctx: Context get() = this

    private var panels: List<Panel> = emptyList()
    private var content: FrameLayout? = null
    private val tabViews = ArrayList<TextView>()
    private var pendingTab = 0

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onCreateInputView(): View {
        Ui.loadTheme(this)
        panels = listOf(
            PlainPanel(this), StylePanel(this), EmojiPanel(this),
            StickerPanel(this), GifPanel(this), ThemePanel(this)
        )
        val labels = listOf("ABC", "✨ AJ", "😀", "Stickers", "GIF", "🎨")

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.panelBgColor())
        }

        // Top bar: tabs + backspace
        tabViews.clear()
        val tabRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        labels.forEachIndexed { i, text ->
            val tv = TextView(this).apply {
                this.text = text
                textSize = 15f
                gravity = Gravity.CENTER
                setTextColor(Ui.labelColor())
                setPadding(Ui.dp(this@AJKeyboardService, 14), 0, Ui.dp(this@AJKeyboardService, 14), 0)
                setOnClickListener { showTab(i) }
            }
            tabViews.add(tv)
            tabRow.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        val del = Ui.key(this, "⌫", 1f, 20f) {}
        Ui.repeatable(del) { backspace() }
        del.layoutParams = LinearLayout.LayoutParams(Ui.dp(this, 56), ViewGroup.LayoutParams.MATCH_PARENT).apply {
            setMargins(Ui.dp(this@AJKeyboardService, 2), Ui.dp(this@AJKeyboardService, 3),
                Ui.dp(this@AJKeyboardService, 4), Ui.dp(this@AJKeyboardService, 3))
        }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bar.addView(
            HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                addView(tabRow, FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
            },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
        )
        bar.addView(del)
        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 40)))

        val frame = FrameLayout(this)
        content = frame
        root.addView(frame, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 252)))

        showTab(pendingTab)
        pendingTab = 0
        return root
    }

    private fun showTab(i: Int) {
        val frame = content ?: return
        val p = panels[i]
        frame.removeAllViews()
        (p.view.parent as? ViewGroup)?.removeView(p.view)
        frame.addView(p.view, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        frame.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, p.heightDp))
        tabViews.forEachIndexed { idx, t ->
            t.background = Ui.bg(this, if (idx == i) Color.parseColor(Ui.LAV) else Color.TRANSPARENT)
        }
        p.onShow()
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        if (!restarting && panels.isNotEmpty()) {
            panels.forEach { it.onStartInput() }
            showTab(0)
        }
    }

    // ---- Host actions used by the panels ----

    override fun recreateKeyboard() {
        pendingTab = 5
        Ui.handler.post { setInputView(onCreateInputView()) }
    }

    override fun typeText(s: String) {
        currentInputConnection?.commitText(s, 1)
    }

    override fun backspace() {
        val ic = currentInputConnection
        val selected = ic?.getSelectedText(0)
        if (ic != null && selected.isNullOrEmpty()) {
            val b = ic.getTextBeforeCursor(3, 0)?.toString() ?: ""
            if (b.length >= 2 && (b.last() == '\u0336' || b.last() == '\u0332')) {
                ic.deleteSurroundingText(2, 0)
                return
            }
            if (b.length == 3) {
                val regionalLetter = b[0] == '\uD83C' && b[1] in '\uDDE6'..'\uDDFF' && b[2] == '\u200C'
                val keycap = b[1] == '\uFE0F' && b[2] == '\u20E3'
                if (regionalLetter || keycap) {
                    ic.deleteSurroundingText(3, 0)
                    return
                }
            }
        }
        sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
    }

    override fun enter() {
        sendDefaultEditorAction(true)
    }

    override fun textBeforeCursor(): String =
        currentInputConnection?.getTextBeforeCursor(40, 0)?.toString() ?: ""

    override fun showSystemPicker() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
    }

    override fun commitBitmap(bmp: Bitmap) {
        val dir = File(cacheDir, "emoji").apply { mkdirs() }
        val now = System.currentTimeMillis()
        dir.listFiles()?.forEach { if (now - it.lastModified() > 10 * 60 * 1000) it.delete() }
        val file = File(dir, "aj_$now.png")
        file.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        commitFile(file, "image/png")
    }

    override fun commitFile(file: File, mime: String) {
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val ic = currentInputConnection ?: return
        val info = currentInputEditorInfo

        val accepted = EditorInfoCompat.getContentMimeTypes(info)
            .any { ClipDescription.compareMimeTypes(mime, it) }
        if (accepted) {
            val contentInfo = InputContentInfoCompat(uri, ClipDescription(file.name, arrayOf(mime)), null)
            val flags =
                if (Build.VERSION.SDK_INT >= 25) InputConnectionCompat.INPUT_CONTENT_GRANT_READ_URI_PERMISSION
                else 0
            if (InputConnectionCompat.commitContent(ic, info, contentInfo, flags, null)) return
        }
        // Fallback: copy to clipboard so the user can paste it
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newUri(contentResolver, file.name, uri))
        Toast.makeText(this, "Copied. Long-press in the box and paste.", Toast.LENGTH_LONG).show()
    }
}
