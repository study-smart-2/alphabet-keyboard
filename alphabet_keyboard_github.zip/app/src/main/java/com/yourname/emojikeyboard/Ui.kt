package com.yourname.emojikeyboard

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File

interface Host {
    val ctx: Context
    fun typeText(s: String)
    fun backspace()
    fun enter()
    fun textBeforeCursor(): String
    fun showSystemPicker()
    fun commitFile(file: File, mime: String)
    fun commitBitmap(bmp: Bitmap)
    fun recreateKeyboard()
}

interface Panel {
    val view: View
    val heightDp: Int get() = 252
    fun onShow() {}
    fun onStartInput() {}
}

class Theme(
    val name: String,
    val panelBg: String,
    val keyBg: String,
    val specialBg: String,
    val keyText: String,
    val accent: String,
    val rainbow: Boolean = false
)

object Ui {
    val handler = Handler(Looper.getMainLooper())

    val themes = listOf(
        Theme("Lavender", "#F3EEFB", "#FFFFFF", "#E2D6F5", "#2B1B4E", "#CDB4F2"),
        Theme("Sky Blue", "#E3EAEE", "#FFFFFF", "#CFDDDD", "#2FB5E8", "#BFE6F5"),
        Theme("Green", "#E8F3EA", "#FFFFFF", "#CFE5D3", "#1F9D45", "#BDE5C8"),
        Theme("Red", "#FBEAEA", "#FFFFFF", "#F2CFCF", "#D62839", "#F7C4C9"),
        Theme("Purple", "#EFE9FA", "#FFFFFF", "#DCCEF4", "#7B3FE4", "#CDB4F2"),
        Theme("Pink", "#FCEAF3", "#FFFFFF", "#F5CCE1", "#E0449B", "#F7C1DD"),
        Theme("Orange", "#FDF0E3", "#FFFFFF", "#F6DABF", "#F07A12", "#F9D3A8"),
        Theme("Gold", "#FBF5DD", "#FFFFFF", "#EFE3AE", "#C28A00", "#F2E39A"),
        Theme("Dark", "#1E1E24", "#3A3A44", "#2C2C34", "#FFFFFF", "#55556A"),
        Theme("Rainbow", "#F3EEFB", "#FFFFFF", "#E2D6F5", "#2B1B4E", "#CDB4F2", true)
    )
    private val rainbowColors = listOf(
        "#E53935", "#FB8C00", "#F9A825", "#43A047", "#1E88E5", "#8E24AA", "#D81B60"
    )
    private val specials = setOf("⌫", "⇧", "⇪", "⏎", "➤", "?123", "ABC", "#!?", "🌐", "अ/क", "←")

    var themeIdx = 0

    fun theme(): Theme = themes[themeIdx]

    fun loadTheme(c: Context) {
        themeIdx = c.getSharedPreferences("aj_prefs", Context.MODE_PRIVATE)
            .getInt("theme", 0).coerceIn(0, themes.size - 1)
    }

    fun saveTheme(c: Context, i: Int) {
        themeIdx = i
        c.getSharedPreferences("aj_prefs", Context.MODE_PRIVATE).edit().putInt("theme", i).apply()
    }

    // Accent / selected color
    val LAV: String get() = theme().accent

    fun panelBgColor(): Int = Color.parseColor(theme().panelBg)
    fun keyBgColor(): Int = Color.parseColor(theme().keyBg)

    // Color of letters printed on keys (Rainbow theme gives every key its own color)
    fun keyColor(label: String): Int {
        val t = theme()
        if (t.rainbow && label.isNotEmpty()) {
            return Color.parseColor(rainbowColors[Math.abs(label.hashCode()) % rainbowColors.size])
        }
        return Color.parseColor(t.keyText)
    }

    // Color for tab / chip labels
    fun labelColor(): Int {
        val t = theme()
        return Color.parseColor(if (t.rainbow) "#2B1B4E" else t.keyText)
    }

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()

    fun bg(c: Context, color: Int, radiusDp: Int = 8): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(c, radiusDp).toFloat()
    }

    fun row(c: Context): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
    }

    fun spacer(c: Context, weight: Float): View = View(c).apply {
        layoutParams = LinearLayout.LayoutParams(0, 1, weight)
    }

    fun key(c: Context, label: String, weight: Float, sizeSp: Float = 20f, onTap: () -> Unit): TextView =
        TextView(c).apply {
            text = label
            textSize = sizeSp
            setTextColor(keyColor(label))
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
            background = bg(c, if (label in specials) Color.parseColor(theme().specialBg) else keyBgColor())
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight).apply {
                setMargins(dp(c, 2), dp(c, 2), dp(c, 2), dp(c, 2))
            }
            setOnClickListener {
                it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                onTap()
            }
        }

    // Press-and-hold repeat (used for backspace)
    fun repeatable(v: View, action: () -> Unit) {
        val r = object : Runnable {
            override fun run() {
                action()
                handler.postDelayed(this, 55)
            }
        }
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.isPressed = true
                    view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    action()
                    handler.postDelayed(r, 400)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.isPressed = false
                    handler.removeCallbacks(r)
                }
            }
            true
        }
    }
}
