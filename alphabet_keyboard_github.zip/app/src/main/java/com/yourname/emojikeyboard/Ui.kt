package com.yourname.emojikeyboard

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File

interface Host {
    val ctx: Context
    fun typeText(s: String)
    fun backspace()
    fun enter()
    fun textBeforeCursor(): String
    fun showSystemPicker()
    fun commitFile(file: File, mime: String)
    fun commitBitmap(bmp: Bitmap)
}

interface Panel {
    val view: View
    val heightDp: Int get() = 252
    fun onShow() {}
    fun onStartInput() {}
}

object Ui {
    const val LAV = "#CDB4F2"
    val handler = Handler(Looper.getMainLooper())

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()

    fun bg(c: Context, color: Int, radiusDp: Int = 8): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(c, radiusDp).toFloat()
    }

    fun row(c: Context): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
    }

    fun spacer(c: Context, weight: Float): View = View(c).apply {
        layoutParams = LinearLayout.LayoutParams(0, 1, weight)
    }

    fun key(c: Context, label: String, weight: Float, sizeSp: Float = 20f, onTap: () -> Unit): TextView =
        TextView(c).apply {
            text = label
            textSize = sizeSp
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
            background = bg(c, Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight).apply {
                setMargins(dp(c, 2), dp(c, 2), dp(c, 2), dp(c, 2))
            }
            setOnClickListener {
                it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                onTap()
            }
        }

    // Press-and-hold repeat (used for backspace)
    fun repeatable(v: View, action: () -> Unit) {
        val r = object : Runnable {
            override fun run() {
                action()
                handler.postDelayed(this, 55)
            }
        }
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    view.isPressed = true
                    view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    action()
                    handler.postDelayed(r, 400)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    view.isPressed = false
                    handler.removeCallbacks(r)
                }
            }
            true
        }
    }
}
