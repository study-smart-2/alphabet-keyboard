package com.yourname.emojikeyboard

import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.core.view.inputmethod.EditorInfoCompat
import androidx.core.view.inputmethod.InputConnectionCompat
import androidx.core.view.inputmethod.InputContentInfoCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File

class EmojiKeyboardService : InputMethodService() {

    override fun onCreateInputView(): View {
        val view = layoutInflater.inflate(R.layout.keyboard_view, null)

        val files = assets.list("emoji").orEmpty()
            .filter { it.endsWith(".gif") }
            .sorted()

        view.findViewById<RecyclerView>(R.id.grid).apply {
            layoutManager = GridLayoutManager(this@EmojiKeyboardService, 5)
            adapter = EmojiAdapter(files) { sendEmoji(it) }
        }

        view.findViewById<View>(R.id.btnGlobe).setOnClickListener {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }
        view.findViewById<View>(R.id.btnDelete).setOnClickListener {
            currentInputConnection?.deleteSurroundingText(1, 0)
        }
        return view
    }

    private fun sendEmoji(name: String) {
        // 1. Copy the asset to cache so a FileProvider can share it
        val dir = File(cacheDir, "emoji").apply { mkdirs() }
        val file = File(dir, name)
        if (!file.exists()) {
            assets.open("emoji/$name").use { input ->
                file.outputStream().use { input.copyTo(it) }
            }
        }
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)

        val ic = currentInputConnection ?: return
        val info = currentInputEditorInfo

        // 2. Insert directly if the target app accepts GIFs
        val accepted = EditorInfoCompat.getContentMimeTypes(info)
            .any { ClipDescription.compareMimeTypes("image/gif", it) }

        if (accepted) {
            val content = InputContentInfoCompat(
                uri, ClipDescription(name, arrayOf("image/gif")), null
            )
            val flags =
                if (Build.VERSION.SDK_INT >= 25)
                    InputConnectionCompat.INPUT_CONTENT_GRANT_READ_URI_PERMISSION
                else 0
            if (InputConnectionCompat.commitContent(ic, info, content, flags, null)) return
        }

        // 3. Fallback: copy to clipboard so the user can paste
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newUri(contentResolver, name, uri))
        Toast.makeText(this, "Copied. Long-press and paste.", Toast.LENGTH_SHORT).show()
    }
}
