package com.yourname.emojikeyboard

data class Lang(
    val name: String,
    val rows: List<List<String>>,
    val shiftRows: List<List<String>>? = null,
    val extra: List<String> = emptyList(),
    val cased: Boolean = true,
    val period: String = ".",
    val shiftLabel: String = "⇧"
)

object Languages {
    private fun r(s: String): List<String> = s.map { it.toString() }
    private fun w(s: String): List<String> = s.split(" ")

    val sym2 = w("@ # ₹ _ & - + ( ) /")
    val sym3 = w("* \" ' : ; ! ? ~ | \\")
    val sym4 = w("\$ € £ % = < > [ ] ^")

    val all: List<Lang> = listOf(
        Lang("English", listOf(r("qwertyuiop"), r("asdfghjkl"), r("zxcvbnm"))),
        Lang(
            "हिन्दी",
            rows = listOf(w("क ख ग घ ङ च छ ज झ ञ"), w("ट ठ ड ढ ण त थ द ध न"), w("प फ ब भ म य र ल व")),
            shiftRows = listOf(w("अ आ इ ई उ ऊ ए ऐ ओ औ"), w("ा ि ी ु ू े ै ो ौ ृ"), w("ं ँ ः ् ऋ ़ ऑ ॉ ॐ")),
            extra = w("श ष स ह क्ष त्र ज्ञ ड़ ढ़ ळ"),
            cased = false,
            period = "।",
            shiftLabel = "अ/क"
        ),
        Lang("Español", listOf(r("qwertyuiop"), r("asdfghjkl"), r("zxcvbnm")), extra = w("á é í ó ú ü ñ ¿ ¡")),
        Lang("Français", listOf(r("azertyuiop"), r("qsdfghjklm"), r("wxcvbn")), extra = w("é è ê à ç ù â î ô û ë ï")),
        Lang("Deutsch", listOf(r("qwertzuiop"), r("asdfghjkl"), r("yxcvbnm")), extra = w("ä ö ü ß")),
        Lang("Português", listOf(r("qwertyuiop"), r("asdfghjkl"), r("zxcvbnm")), extra = w("á à â ã é ê í ó ô õ ú ç")),
        Lang("Русский", listOf(r("йцукенгшщзхъ"), r("фывапролджэ"), r("ячсмитьбю"))),
        Lang(
            "العربية",
            listOf(r("ضصثقفغعهخحجد"), r("شسيبلاتنمكط"), listOf("ئ", "ء", "ؤ", "ر", "لا", "ى", "ة", "و", "ز", "ظ")),
            cased = false
        )
    )

    // Combining marks get a dotted circle so they are readable on a key
    fun label(s: String): String {
        val t = Character.getType(s[0])
        return if (t == Character.NON_SPACING_MARK.toInt() || t == Character.COMBINING_SPACING_MARK.toInt())
            "\u25CC" + s else s
    }

    fun caseOf(s: String, up: Boolean): String {
        if (!up) return s
        val u = s.uppercase()
        return if (u.length == s.length) u else s
    }
}
