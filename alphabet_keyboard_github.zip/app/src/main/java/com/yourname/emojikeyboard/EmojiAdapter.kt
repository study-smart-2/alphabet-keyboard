package com.yourname.emojikeyboard

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class EmojiAdapter(
    private val files: List<String>,
    private val onClick: (String) -> Unit
) : RecyclerView.Adapter<EmojiAdapter.VH>() {

    class VH(val img: ImageView) : RecyclerView.ViewHolder(img)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val img = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_emoji, parent, false) as ImageView
        return VH(img)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val name = files[position]
        Glide.with(holder.img.context.applicationContext)
            .asGif()
            .load("file:///android_asset/emoji/$name")
            .into(holder.img)
        holder.img.setOnClickListener { onClick(name) }
    }

    override fun getItemCount() = files.size
}
