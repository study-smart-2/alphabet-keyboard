package com.yourname.emojikeyboard

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.bumptech.glide.Glide
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

private class Gif(val preview: String, val full: String)

// GIF search powered by GIPHY (needs a free API key, set in the AJ Keyboard app)
class GifPanel(private val host: Host) : Panel {
    private val ctx: Context = host.ctx
    private val prefs = ctx.getSharedPreferences("aj_prefs", Context.MODE_PRIVATE)

    private val cats = listOf(
        "🔥 Trending" to "", "😂 Funny" to "funny", "❤️ Love" to "love", "👍 Yes" to "yes",
        "👎 No" to "no", "🎉 Party" to "party", "😭 Sad" to "sad", "🙏 Thanks" to "thanks",
        "👋 Hello" to "hello", "😴 Sleepy" to "sleepy", "🔎 Typed text" to "@typed"
    )
    private var gifs: List<Gif> = emptyList()
    private var grid: GridView? = null
    private var status: TextView? = null
    private val tabs = ArrayList<TextView>()
    private var requestId = 0
    private var loadedOnce = false

    override val view: View by lazy { build() }

    override fun onShow() {
        if (!loadedOnce) {
            loadedOnce = true
            pick(0)
        }
    }

    private fun setStatus(msg: String?) {
        val s = status ?: return
        if (msg == null) {
            s.visibility = View.GONE
        } else {
            s.text = msg
            s.visibility = View.VISIBLE
        }
    }

    private fun pick(i: Int) {
        tabs.forEachIndexed { idx, t ->
            t.background = Ui.bg(ctx, if (idx == i) Color.parseColor(Ui.LAV) else Color.TRANSPARENT)
        }
        val q = cats[i].second
        if (q == "@typed") {
            val typed = host.textBeforeCursor().trim().takeLast(30)
            if (typed.isEmpty()) {
                setStatus("Type a word in the chat box first, then tap this to search")
            } else {
                load(typed)
            }
        } else {
            load(q)
        }
    }

    private fun load(query: String) {
        val key = (prefs.getString("giphy_key", "") ?: "").trim()
        if (key.isEmpty()) {
            setStatus("Add your free GIPHY key: open the AJ Keyboard app and paste it there")
            return
        }
        setStatus("Loading...")
        requestId++
        val myId = requestId
        Thread {
            try {
                val base = if (query.isBlank())
                    "https://api.giphy.com/v1/gifs/trending?"
                else
                    "https://api.giphy.com/v1/gifs/search?q=" + URLEncoder.encode(query, "UTF-8") + "&"
                val url = URL(base + "api_key=" + URLEncoder.encode(key, "UTF-8") + "&limit=30&rating=pg-13")
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                val arr = JSONObject(body).getJSONArray("data")
                val list = ArrayList<Gif>()
                for (i in 0 until arr.length()) {
                    val img = arr.getJSONObject(i).getJSONObject("images")
                    val prev = img.getJSONObject("fixed_height_small").getString("url")
                    val full = img.getJSONObject("fixed_height").getString("url")
                    list.add(Gif(prev, full))
                }
                Ui.handler.post {
                    if (myId == requestId) {
                        gifs = list
                        grid?.adapter = Adapter()
                        setStatus(if (list.isEmpty()) "No GIFs found" else null)
                    }
                }
            } catch (e: Exception) {
                Ui.handler.post {
                    if (myId == requestId) setStatus("Could not load GIFs. Check internet and your GIPHY key.")
                }
            }
        }.start()
    }

    private fun send(g: Gif) {
        setStatus("Sending...")
        Thread {
            try {
                val dir = File(ctx.cacheDir, "emoji").apply { mkdirs() }
                val f = File(dir, "gif_" + System.currentTimeMillis() + ".gif")
                val conn = URL(g.full).openConnection() as HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 15000
                conn.inputStream.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                Ui.handler.post {
                    host.commitFile(f, "image/gif")
                    setStatus(null)
                }
            } catch (e: Exception) {
                Ui.handler.post { setStatus("Could not send this GIF. Try another.") }
            }
        }.start()
    }

    private inner class Adapter : BaseAdapter() {
        override fun getCount() = gifs.size
        override fun getItem(position: Int): Any = gifs[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val iv = (convertView as? ImageView) ?: ImageView(ctx).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setPadding(Ui.dp(ctx, 2), Ui.dp(ctx, 2), Ui.dp(ctx, 2), Ui.dp(ctx, 2))
                layoutParams = AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(ctx, 84))
            }
            Glide.with(ctx.applicationContext).asGif().load(gifs[position].preview).into(iv)
            return iv
        }
    }

    private fun build(): View {
        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        cats.forEachIndexed { i, c ->
            val tv = TextView(ctx).apply {
                text = c.first
                setTextColor(Ui.labelColor())
                textSize = 14f
                gravity = Gravity.CENTER
                setPadding(Ui.dp(ctx, 12), 0, Ui.dp(ctx, 12), 0)
                setOnClickListener { pick(i) }
            }
            tabs.add(tv)
            row.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        root.addView(
            HorizontalScrollView(ctx).apply {
                isHorizontalScrollBarEnabled = false
                addView(row, FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
            },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(ctx, 40))
        )
        val st = TextView(ctx).apply {
            textSize = 13f
            setTextColor(Color.parseColor("#7A5FB0"))
            setPadding(Ui.dp(ctx, 10), Ui.dp(ctx, 6), Ui.dp(ctx, 10), Ui.dp(ctx, 6))
            visibility = View.GONE
        }
        status = st
        root.addView(st, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val g = GridView(ctx).apply {
            numColumns = 3
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            selector = ColorDrawable(Color.TRANSPARENT)
            setOnItemClickListener { _, _, pos, _ -> send(gifs[pos]) }
        }
        grid = g
        root.addView(g, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(
            TextView(ctx).apply {
                text = "Powered by GIPHY"
                textSize = 11f
                gravity = Gravity.CENTER
                setTextColor(Color.parseColor("#7A5FB0"))
            },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(ctx, 18))
        )
        return root
    }
}
