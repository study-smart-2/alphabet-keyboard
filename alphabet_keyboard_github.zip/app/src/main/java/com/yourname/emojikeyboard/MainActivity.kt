package com.yourname.emojikeyboard

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("aj_prefs", Context.MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(48, 64, 48, 48)
        }
        root.addView(TextView(this).apply {
            text = "AJ Keyboard"
            textSize = 26f
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "Typing, 8 languages, emoji, stickers, GIFs and colored 3D letters"
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 24)
        })
        root.addView(Button(this).apply {
            text = "1. Enable keyboard"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "2. Switch to this keyboard"
            setOnClickListener {
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
            }
        })
        root.addView(EditText(this).apply { hint = "3. Tap here and test" })

        root.addView(TextView(this).apply {
            text = "GIF setup (free): create an app on developers.giphy.com, copy the API key and paste it below."
            setPadding(0, 40, 0, 8)
        })
        val keyBox = EditText(this).apply {
            hint = "GIPHY API key"
            setText(prefs.getString("giphy_key", ""))
            setSingleLine(true)
        }
        root.addView(keyBox)
        root.addView(Button(this).apply {
            text = "Save GIPHY key"
            setOnClickListener {
                prefs.edit().putString("giphy_key", keyBox.text.toString().trim()).apply()
                Toast.makeText(this@MainActivity, "Saved", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(Button(this).apply {
            text = "Open GIPHY developers page"
            setOnClickListener {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://developers.giphy.com/")))
            }
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }
}
