package com.yourname.emojikeyboard

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.GridView
import android.widget.HorizontalScrollView
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

object EmojiData {
    private fun e(s: String): List<String> = s.trim().split(Regex("\\s+"))

    val smileys = e("""😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 🙃 😉 😌 😍 🥰 😘 😗 😙 😚 😋 😛 😝 😜 🤪 🤨 🧐 🤓 😎 🤩 🥳 😏 😒 😞 😔 😟 😕 🙁 😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 😓 🤗 🤔 🤭 🤫 🤥 😶 😐 😑 😬 🙄 😯 😦 😧 😮 😲 🥱 😴 🤤 😪 😵 🤐 🥴 🤢 🤮 🤧 😷 🤒 🤕 🤑 🤠 😈 👿 👹 👺 🤡 💩 👻 💀 👽 👾 🤖 🎃 😺 😸 😹 😻 😼 😽 🙀 😿 😾""")

    val people = e("""👋 🤚 ✋ 🖖 👌 🤏 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 👇 👍 👎 ✊ 👊 🤛 🤜 👏 🙌 👐 🤲 🤝 🙏 ✍️ 💅 🤳 💪 🦵 🦶 👂 👃 🧠 👀 👅 👄 👶 🧒 👦 👧 🧑 👨 👩 🧓 👴 👵 💃 🕺 🙋 🙆 🙅 🤷 🤦 💁 🙇""")

    val hearts = e("""❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 💕 💞 💓 💗 💖 💘 💝 💟 ✨ ⭐ 🌟 💫 ⚡ 🔥 💥 💯 ✅ ❌ ❓ ❗ 💤 🎉 🎊 🎁 🎈 🏆 🥇 🥈 🥉 💬 💭 🔔 🎵 🎶 ➕ ➖ ➡️ ⬅️ ⬆️ ⬇️ ♻️ ⚠️ 🚫""")

    val nature = e("""🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🙈 🙉 🙊 🐔 🐧 🐦 🐤 🦆 🦅 🦉 🦇 🐺 🐗 🐴 🦄 🐝 🐛 🦋 🐌 🐞 🐜 🐢 🐍 🦎 🐙 🦑 🦀 🐠 🐟 🐬 🐳 🐋 🦈 🐊 🐘 🦒 🦓 🐎 🐫 🌵 🎄 🌲 🌳 🌴 🌱 🌿 🍀 🍁 🍂 🍃 🌺 🌻 🌹 🌷 🌼 🌸 💐 🌞 🌝 🌛 🌈 ☁️ ⛅ ☔ ❄️ ☃️ 💧 🌊""")

    val food = e("""🍏 🍎 🍐 🍊 🍋 🍌 🍉 🍇 🍓 🍈 🍒 🍑 🥭 🍍 🥥 🥝 🍅 🥑 🍆 🥔 🥕 🌽 🥒 🥦 🍄 🥜 🍞 🥐 🥖 🧀 🍖 🍗 🥩 🥓 🍔 🍟 🍕 🌭 🥪 🌮 🌯 🥗 🍝 🍜 🍲 🍛 🍣 🍱 🥟 🍤 🍙 🍚 🍘 🍦 🍧 🍨 🍩 🍪 🎂 🍰 🧁 🍫 🍬 🍭 🍮 🍯 ☕ 🍵 🥤 🍺 🍻 🥂 🍷 🍸 🍹 🍾""")

    val activity = e("""⚽ 🏀 🏈 ⚾ 🎾 🏐 🏉 🎱 🏓 🏸 🥅 🏏 ⛳ 🏹 🎣 🥊 🥋 ⛸️ 🎿 🏂 🏋️ 🤸 🏊 🚴 🎯 🎮 🕹️ 🎲 🎭 🎨 🎬 🎤 🎧 🎼 🎹 🥁 🎷 🎺 🎸 🎻""")

    val objects = e("""🚗 🚕 🚙 🚌 🚎 🚓 🚑 🚒 🚚 🚜 🏍️ 🚲 🛵 ✈️ 🚀 🛸 🚁 ⛵ 🚢 🏠 🏢 🏰 🗼 ⛪ 🕌 🌍 🌎 🌏 ⌚ 📱 💻 ⌨️ 🖥️ 📷 📹 📞 📺 📻 ⏰ 🔋 💡 🔦 💰 💳 💎 🔧 🔨 🔑 🚪 🛏️ 🛒 📦 📚 📖 ✏️ 📝 📌 📎 ✂️ 🔒 🔓""")

    val flags = e("""🇮🇳 🇺🇸 🇬🇧 🇵🇰 🇧🇩 🇳🇵 🇱🇰 🇦🇪 🇸🇦 🇨🇦 🇦🇺 🇫🇷 🇩🇪 🇪🇸 🇮🇹 🇷🇺 🇨🇳 🇯🇵 🇰🇷 🇧🇷 🇲🇽 🇿🇦 🏁 🚩""")
}

class EmojiPanel(private val host: Host) : Panel {
    private val ctx: Context = host.ctx
    private val prefs = ctx.getSharedPreferences("aj_prefs", Context.MODE_PRIVATE)

    private class Cat(val icon: String, val items: List<String>)

    private val cats = listOf(
        Cat("🕘", emptyList()), Cat("😀", EmojiData.smileys), Cat("👋", EmojiData.people),
        Cat("❤️", EmojiData.hearts), Cat("🐶", EmojiData.nature), Cat("🍔", EmojiData.food),
        Cat("⚽", EmojiData.activity), Cat("🚗", EmojiData.objects), Cat("🏳️", EmojiData.flags)
    )
    private var grid: GridView? = null
    private var items: List<String> = emptyList()
    private val tabViews = ArrayList<TextView>()
    private var catIdx = 1

    override val view: View by lazy { build() }

    override fun onShow() {
        select(catIdx)
    }

    private fun recents(): List<String> {
        val s = prefs.getString("emoji_recent", "") ?: ""
        return if (s.isBlank()) emptyList() else s.split(" ")
    }

    private fun addRecent(e: String) {
        val list = ArrayList(recents())
        list.remove(e)
        list.add(0, e)
        prefs.edit().putString("emoji_recent", list.take(32).joinToString(" ")).apply()
    }

    private fun select(i: Int) {
        catIdx = i
        items = if (i == 0) recents() else cats[i].items
        grid?.adapter = Adapter()
        tabViews.forEachIndexed { idx, t ->
            t.background = Ui.bg(ctx, if (idx == i) Color.parseColor(Ui.LAV) else Color.TRANSPARENT)
        }
    }

    private inner class Adapter : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val tv = (convertView as? TextView) ?: TextView(ctx).apply {
                textSize = 26f
                gravity = Gravity.CENTER
                setPadding(0, Ui.dp(ctx, 6), 0, Ui.dp(ctx, 6))
            }
            tv.text = items[position]
            return tv
        }
    }

    private fun build(): View {
        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val tabs = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        cats.forEachIndexed { i, cat ->
            val tv = TextView(ctx).apply {
                text = cat.icon
                textSize = 20f
                gravity = Gravity.CENTER
                setPadding(Ui.dp(ctx, 14), 0, Ui.dp(ctx, 14), 0)
                setOnClickListener { select(i) }
            }
            tabViews.add(tv)
            tabs.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        root.addView(
            HorizontalScrollView(ctx).apply {
                isHorizontalScrollBarEnabled = false
                addView(tabs, FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
            },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(ctx, 40))
        )
        val g = GridView(ctx).apply {
            numColumns = 8
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            selector = ColorDrawable(Color.TRANSPARENT)
            setOnItemClickListener { _, _, pos, _ ->
                val e = items[pos]
                host.typeText(e)
                addRecent(e)
            }
        }
        grid = g
        root.addView(g, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        select(catIdx)
        return root
    }
}
