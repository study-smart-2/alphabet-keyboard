package com.yourname.emojikeyboard

import android.content.Context
import android.graphics.Color
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

// The simple everyday keyboard: multi-language letters, numbers, symbols
class PlainPanel(private val host: Host) : Panel {
    override val heightDp = 252
    private val ctx: Context = host.ctx
    private val prefs = ctx.getSharedPreferences("aj_prefs", Context.MODE_PRIVATE)
    private var langIdx = prefs.getInt("lang", 0).coerceIn(0, Languages.all.size - 1)
    private var shift = 1            // 0 = off, 1 = next letter, 2 = lock (Hindi: page toggle)
    private var symbols = false
    private var pickingLang = false
    private var lastShiftTap = 0L
    private var prevChar = ' '
    private val container = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    override val view: View get() = container

    private val lang: Lang get() = Languages.all[langIdx]

    init {
        shift = if (lang.cased) 1 else 0
        rebuild()
    }

    override fun onStartInput() {
        symbols = false
        pickingLang = false
        prevChar = ' '
        shift = if (lang.cased) 1 else 0
        rebuild()
    }

    private fun refreshLater() {
        container.post { rebuild() }
    }

    private fun display(s: String): String = Languages.caseOf(s, lang.cased && shift > 0)

    private fun typed(s: String) {
        host.typeText(s)
        prevChar = s.last()
        if (shift == 1) {
            shift = 0
            refreshLater()
        }
    }

    private fun onSpace() {
        host.typeText(" ")
        if (lang.cased && (prevChar == '.' || prevChar == '!' || prevChar == '?')) {
            shift = 1
            refreshLater()
        }
        prevChar = ' '
    }

    private fun onShift() {
        val now = System.currentTimeMillis()
        shift = when {
            shift == 0 -> 1
            shift == 1 && now - lastShiftTap < 400 -> 2
            else -> 0
        }
        lastShiftTap = now
        refreshLater()
    }

    private fun rebuild() {
        container.removeAllViews()
        if (pickingLang) {
            buildPicker()
            return
        }
        val l = lang
        if (symbols) {
            container.addView(digitsRow())
            container.addView(plainRow(Languages.sym2, false))
            container.addView(plainRow(Languages.sym3, false))
            container.addView(plainRow(Languages.sym4, true))
        } else {
            if (l.extra.isNotEmpty()) container.addView(extraRow(l))
            container.addView(digitsRow())
            val page = if (!l.cased && shift > 0) (l.shiftRows ?: l.rows) else l.rows
            page.forEachIndexed { i, keys -> container.addView(letterRow(l, keys, i)) }
        }
        container.addView(bottomRow(l))
    }

    private fun bksp(): TextView {
        val k = Ui.key(ctx, "⌫", 1.5f) {}
        Ui.repeatable(k) {
            host.backspace()
            prevChar = ' '
        }
        return k
    }

    private fun digitsRow(): LinearLayout {
        val row = Ui.row(ctx)
        for (d in "1234567890") row.addView(Ui.key(ctx, d.toString(), 1f) { typed(d.toString()) })
        return row
    }

    private fun plainRow(keys: List<String>, withBack: Boolean): LinearLayout {
        val row = Ui.row(ctx)
        for (s in keys) row.addView(Ui.key(ctx, s, 1f) { typed(s) })
        if (withBack) row.addView(bksp())
        return row
    }

    private fun extraRow(l: Lang): LinearLayout {
        val row = Ui.row(ctx)
        for (s in l.extra) {
            val d = display(s)
            row.addView(Ui.key(ctx, Languages.label(d), 1f, 17f) { typed(d) })
        }
        return row
    }

    private fun shiftKey(l: Lang): TextView {
        val label = if (!l.cased) l.shiftLabel else if (shift == 2) "⇪" else "⇧"
        val k = Ui.key(ctx, label, 1.5f, if (l.cased) 20f else 15f) { onShift() }
        if (shift > 0) k.background = Ui.bg(ctx, Color.parseColor(Ui.LAV))
        return k
    }

    private fun letterRow(l: Lang, keys: List<String>, i: Int): LinearLayout {
        val row = Ui.row(ctx)
        val size = if (keys.size >= 11) 17f else 20f
        val narrow = keys.size <= 9
        if (i == 1 && narrow) row.addView(Ui.spacer(ctx, 0.5f))
        if (i == 2) {
            if (l.cased || l.shiftRows != null) row.addView(shiftKey(l)) else row.addView(Ui.spacer(ctx, 1.5f))
        }
        for (k in keys) {
            val d = display(k)
            row.addView(Ui.key(ctx, Languages.label(d), 1f, size) { typed(d) })
        }
        if (i == 1 && narrow) row.addView(Ui.spacer(ctx, 0.5f))
        if (i == 2) row.addView(bksp())
        return row
    }

    private fun bottomRow(l: Lang): LinearLayout {
        val row = Ui.row(ctx)
        row.addView(Ui.key(ctx, if (symbols) "ABC" else "?123", 1.5f, 15f) {
            symbols = !symbols
            refreshLater()
        })
        val globe = Ui.key(ctx, "🌐", 1.2f, 18f) {
            pickingLang = true
            refreshLater()
        }
        globe.setOnLongClickListener {
            host.showSystemPicker()
            true
        }
        row.addView(globe)
        row.addView(Ui.key(ctx, ",", 1f) { typed(",") })
        row.addView(Ui.key(ctx, l.name, 4f, 13f) { onSpace() })
        row.addView(Ui.key(ctx, l.period, 1f) { typed(l.period) })
        row.addView(Ui.key(ctx, "⏎", 1.5f) { host.enter() })
        return row
    }

    private fun buildPicker() {
        val langs = Languages.all
        var i = 0
        while (i < langs.size) {
            val row = Ui.row(ctx)
            val end = minOf(i + 3, langs.size)
            for (j in i until end) {
                val l = langs[j]
                val k = Ui.key(ctx, l.name, 1f, 16f) {
                    langIdx = j
                    prefs.edit().putInt("lang", j).apply()
                    pickingLang = false
                    symbols = false
                    shift = if (l.cased) 1 else 0
                    refreshLater()
                }
                if (j == langIdx) k.background = Ui.bg(ctx, Color.parseColor(Ui.LAV))
                row.addView(k)
            }
            for (p in end until i + 3) row.addView(Ui.spacer(ctx, 1f))
            container.addView(row)
            i += 3
        }
        val back = Ui.row(ctx)
        back.addView(Ui.key(ctx, "←", 1f, 20f) {
            pickingLang = false
            refreshLater()
        })
        container.addView(back)
    }
}
