package com.yourname.emojikeyboard

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

// AJ Style: colored 3D letters (sent as one image) and styled Unicode text letters
class StylePanel(private val host: Host) : Panel {
    override val heightDp = 292
    private val ctx: Context = host.ctx

    // Colored styles: single colors, then combinations (letters cycle through the colors)
    private val imgStyles: List<List<String>> = listOf(
        listOf("green3d"), listOf("lime"), listOf("gold"), listOf("red"),
        listOf("blue"), listOf("purple"), listOf("pink"), listOf("orange"),
        listOf("green3d", "lime"),
        listOf("red", "orange", "gold"),
        listOf("pink", "purple", "blue"),
        listOf("gold", "green3d"),
        listOf("blue", "lime"),
        listOf("red", "orange", "gold", "lime", "blue", "purple", "pink")
    )
    // Text styles. Index 0 = Regional letters (colored tiles on most phones), typed with a
    // zero-width non-joiner after each letter so they do not merge into flags.
    private val textUpper = intArrayOf(0x1F1E6, 0x24B6, 0x1F150, 0x1F130, 0x1F170, 0x1D400, 0x1D5D4)
    private val textLower = intArrayOf(0, 0x24D0, 0, 0, 0, 0x1D41A, 0x1D5EE) // 0 = no small letters
    private val REGIONAL = 0

    private class Entry(val sets: List<String>?, val t: Int)

    // Order in the chip row: Regional (typable), colored image styles, other text styles
    private val entries: List<Entry> =
        listOf(Entry(null, 0)) +
            imgStyles.map { Entry(it, -1) } +
            (1 until 7).map { Entry(null, it) }

    private val signNames = mapOf(
        '!' to "excl", '?' to "ques", '.' to "dot", ',' to "comma", ':' to "colon", ';' to "semi",
        '-' to "minus", '_' to "under", '+' to "plus", '=' to "equal", '*' to "star", '/' to "slash",
        '&' to "amp", '@' to "at", '#' to "hash", '$' to "dollar", '%' to "percent", '(' to "lpar",
        ')' to "rpar", '\'' to "apos", '"' to "quote", '~' to "tilde", '₹' to "rupee"
    )

    private var current = 0
    private var upper = true
    private var signs = false
    private val buffer = StringBuilder()
    private val keys = ArrayList<CharKey>()
    private val chips = ArrayList<View>()
    private val cache = HashMap<String, Bitmap>()
    private var previewScroll: HorizontalScrollView? = null
    private var previewRow: LinearLayout? = null
    private var keysBox: LinearLayout? = null
    private var enterKey: TextView? = null
    private var shiftKey: TextView? = null

    override val view: View by lazy { build() }

    private fun isImage() = entries[current].sets != null
    private fun dp(v: Int) = Ui.dp(ctx, v)

    private fun assetName(c: Char): String {
        val s = signNames[c]
        return when {
            s != null -> "s_$s"
            c.isUpperCase() -> "u_$c"
            c.isLowerCase() -> "l_$c"
            else -> "$c"
        }
    }

    private fun bmp(style: String, c: Char, full: Boolean = false): Bitmap? = try {
        cache.getOrPut((if (full) "F" else "T") + style + "/" + c) {
            val opts = BitmapFactory.Options()
            if (!full) opts.inSampleSize = 2
            ctx.assets.open("letters/$style/${assetName(c)}.png").use {
                BitmapFactory.decodeStream(it, null, opts)!!
            }
        }
    } catch (e: Exception) {
        null
    }

    private fun styleAt(n: Int): String {
        val sets = entries[current].sets ?: return "green3d"
        return sets[n % sets.size]
    }

    private fun partsFor(text: String, full: Boolean): List<Bitmap?> {
        var n = 0
        return text.map { ch ->
            if (ch == ' ') null else {
                val b = bmp(styleAt(n), ch, full)
                n++
                b
            }
        }
    }

    private fun styled(c: Char, t: Int): String =
        if (c.isLowerCase() && textLower[t] != 0)
            String(Character.toChars(textLower[t] + (c - 'a')))
        else
            String(Character.toChars(textUpper[t] + (c.uppercaseChar() - 'A')))

    private fun thumbFor(sets: List<String>): Bitmap? {
        val n = if (sets.size == 1) 1 else minOf(sets.size, 4)
        val parts = ArrayList<Bitmap>()
        for (k in 0 until n) {
            val b = bmp(sets[k % sets.size], "ABCD"[k])
            if (b != null) parts.add(b)
        }
        if (parts.isEmpty()) return null
        if (parts.size == 1) return parts[0]
        val w = parts.fold(0) { acc, p -> acc + p.width + 2 }
        val out = Bitmap.createBitmap(w, parts[0].height, Bitmap.Config.ARGB_8888)
        val cv = Canvas(out)
        var x = 0
        for (p in parts) {
            cv.drawBitmap(p, x.toFloat(), 0f, null)
            x += p.width + 2
        }
        return out
    }

    // What a key shows in a text style (digits become keycaps in Regional style)
    private fun textLabel(c: Char): String {
        val t = entries[current].t
        return when {
            c.isLetter() -> styled(c, t)
            c.isDigit() && t == REGIONAL -> "$c\uFE0F\u20E3"
            else -> c.toString()
        }
    }

    private fun textTyped(c: Char): String =
        textLabel(c) + (if (c.isLetter() && entries[current].t == REGIONAL) "\u200C" else "")

    // A letter / number / sign key showing either a colored image or a text glyph
    private inner class CharKey(val c: Char) {
        val tv = TextView(ctx).apply {
            textSize = 20f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
        }
        val iv = ImageView(ctx).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(4), dp(4), dp(4), dp(4))
            visibility = View.GONE
        }
        val view = FrameLayout(ctx).apply {
            background = Ui.bg(ctx, Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                setMargins(dp(2), dp(2), dp(2), dp(2))
            }
            addView(tv, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            addView(iv, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            setOnClickListener { onChar(shown()) }
        }

        fun shown(): Char = if (c.isLetter() && !upper) c.lowercaseChar() else c

        fun refresh() {
            if (isImage()) {
                tv.visibility = View.GONE
                iv.visibility = View.VISIBLE
                iv.setImageBitmap(bmp(styleAt(buffer.count { it != ' ' }), shown()))
            } else {
                iv.visibility = View.GONE
                tv.visibility = View.VISIBLE
                tv.text = textLabel(shown())
            }
        }
    }

    private fun onChar(c: Char) {
        if (isImage()) {
            buffer.append(c)
            refreshBuffer()
        } else {
            host.typeText(textTyped(c))
        }
    }

    private fun onSpace() {
        if (isImage() && buffer.isNotEmpty()) {
            buffer.append(' ')
            refreshBuffer()
        } else {
            host.typeText(" ")
        }
    }

    private fun onDelete() {
        if (isImage() && buffer.isNotEmpty()) {
            buffer.setLength(buffer.length - 1)
            refreshBuffer()
        } else {
            host.backspace()
        }
    }

    private fun onEnter() {
        if (isImage() && buffer.isNotEmpty()) sendImage() else host.enter()
    }

    private fun refreshBuffer() {
        enterKey?.text = if (isImage() && buffer.isNotEmpty()) "➤" else "⏎"
        if ((entries[current].sets?.size ?: 0) > 1) keys.forEach { it.refresh() }
        val row = previewRow ?: return
        row.removeAllViews()
        if (!isImage()) return
        if (buffer.isEmpty()) {
            row.addView(TextView(ctx).apply {
                text = "Tap letters, then press ➤ to send"
                setTextColor(Color.parseColor("#7A5FB0"))
                textSize = 14f
                setPadding(dp(10), 0, dp(10), 0)
            })
            return
        }
        for (b in partsFor(buffer.toString(), false)) {
            if (b == null) {
                row.addView(View(ctx).apply { layoutParams = LinearLayout.LayoutParams(dp(14), 1) })
            } else {
                row.addView(ImageView(ctx).apply {
                    setImageBitmap(b)
                    adjustViewBounds = true
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, dp(36)
                    ).apply { setMargins(dp(1), 0, dp(1), 0) }
                })
            }
        }
        previewScroll?.post { previewScroll?.fullScroll(View.FOCUS_RIGHT) }
    }

    private fun refresh() {
        keys.forEach { it.refresh() }
        chips.forEachIndexed { i, v ->
            v.background = Ui.bg(ctx, if (i == current) Color.parseColor(Ui.LAV) else Color.TRANSPARENT)
        }
        shiftKey?.background = Ui.bg(ctx, if (upper) Color.parseColor(Ui.LAV) else Color.WHITE)
        previewScroll?.visibility = if (isImage()) View.VISIBLE else View.GONE
        refreshBuffer()
    }

    // Stitch the typed letters into one PNG and send it
    private fun sendImage() {
        val text = buffer.toString().trim()
        if (text.isEmpty()) return
        val parts = partsFor(text, true)
        val letterGap = 4
        val spaceGap = 60
        var width = 0
        for (b in parts) width += if (b == null) spaceGap else b.width + letterGap
        val out = Bitmap.createBitmap(maxOf(width, 1), 256, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        var x = 0
        for (b in parts) {
            if (b == null) {
                x += spaceGap
            } else {
                canvas.drawBitmap(b, x.toFloat(), 0f, null)
                x += b.width + letterGap
            }
        }
        host.commitBitmap(out)
        buffer.setLength(0)
        refreshBuffer()
    }

    private fun bksp(): TextView {
        val k = Ui.key(ctx, "⌫", 1.5f) {}
        Ui.repeatable(k) { onDelete() }
        return k
    }

    private fun rebuildKeys() {
        val box = keysBox ?: return
        box.removeAllViews()
        keys.clear()

        val digits = Ui.row(ctx)
        for (d in "1234567890") {
            val k = CharKey(d)
            keys.add(k)
            digits.addView(k.view)
        }
        box.addView(digits)

        if (!signs) {
            val rows = listOf("QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM")
            rows.forEachIndexed { idx, letters ->
                val row = Ui.row(ctx)
                if (idx == 1) row.addView(Ui.spacer(ctx, 0.5f))
                if (idx == 2) {
                    val s = Ui.key(ctx, "⇧", 1.5f) {
                        upper = !upper
                        refresh()
                    }
                    shiftKey = s
                    row.addView(s)
                }
                for (ch in letters) {
                    val k = CharKey(ch)
                    keys.add(k)
                    row.addView(k.view)
                }
                if (idx == 1) row.addView(Ui.spacer(ctx, 0.5f))
                if (idx == 2) row.addView(bksp())
                box.addView(row)
            }
        } else {
            val rows = listOf("! ? . , : ; ' \" ( )", "- _ + = * / & @ # \$", "% ~ ₹")
            rows.forEachIndexed { idx, line ->
                val row = Ui.row(ctx)
                for (t in line.split(" ")) {
                    val k = CharKey(t[0])
                    keys.add(k)
                    row.addView(k.view)
                }
                if (idx == 2) {
                    row.addView(Ui.spacer(ctx, 4f))
                    row.addView(bksp())
                }
                box.addView(row)
            }
        }

        val bottom = Ui.row(ctx)
        bottom.addView(Ui.key(ctx, if (signs) "ABC" else "#!?", 1.5f, 15f) {
            signs = !signs
            box.post { rebuildKeys() }
        })
        bottom.addView(Ui.key(ctx, "space", 5f, 15f) { onSpace() })
        val enter = Ui.key(ctx, "⏎", 1.5f) { onEnter() }
        enterKey = enter
        bottom.addView(enter)
        box.addView(bottom)
        refresh()
    }

    override fun onStartInput() {
        buffer.setLength(0)
        if (keysBox != null) refresh()
    }

    private fun build(): View {
        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }

        // Style chips (see the order in `entries`)
        val chipRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        entries.forEachIndexed { i, e ->
            val sets = e.sets
            val chip: View
            if (sets != null) {
                val bm = thumbFor(sets)
                val h = dp(32)
                val w = if (bm != null) (h * bm.width / bm.height.toFloat()).toInt() + dp(16) else dp(50)
                chip = ImageView(ctx).apply {
                    setImageBitmap(bm)
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    setPadding(dp(8), dp(3), dp(8), dp(3))
                    layoutParams = LinearLayout.LayoutParams(w, dp(38))
                    setOnClickListener {
                        current = i
                        refresh()
                    }
                }
            } else {
                chip = TextView(ctx).apply {
                    text = styled('A', e.t)
                    textSize = 22f
                    gravity = Gravity.CENTER
                    setPadding(dp(14), dp(2), dp(14), dp(2))
                    setOnClickListener {
                        current = i
                        refresh()
                    }
                }
            }
            chips.add(chip)
            chipRow.addView(chip)
        }
        root.addView(
            HorizontalScrollView(ctx).apply {
                isHorizontalScrollBarEnabled = false
                addView(chipRow, FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
            },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40))
        )

        // Word preview (colored styles only)
        val pRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        previewRow = pRow
        val pScroll = HorizontalScrollView(ctx).apply {
            isHorizontalScrollBarEnabled = false
            background = Ui.bg(ctx, Color.parseColor("#E6DAF8"))
            addView(pRow, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        previewScroll = pScroll
        root.addView(
            pScroll,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)).apply {
                setMargins(dp(2), dp(2), dp(2), dp(2))
            }
        )

        val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        keysBox = box
        root.addView(box, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        rebuildKeys()
        return root
    }
}
